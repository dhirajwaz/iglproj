package com.mis.user;

public class PlantBean {

	String plant_name;
	String plant_code;
	String plant_state;
	int zone_id;
	public String getPlant_name() {
		return plant_name;
	}
	public void setPlant_name(String plant_name) {
		this.plant_name = plant_name;
	}
	public String getPlant_code() {
		return plant_code;
	}
	public void setPlant_code(String plant_code) {
		this.plant_code = plant_code;
	}
	public String getPlant_state() {
		return plant_state;
	}
	public void setPlant_state(String plant_state) {
		this.plant_state = plant_state;
	}
	public int getZone_id() {
		return zone_id;
	}
	public void setZone_id(int zone_id) {
		this.zone_id = zone_id;
	}
	
}

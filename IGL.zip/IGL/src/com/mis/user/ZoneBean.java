package com.mis.user;

public class ZoneBean {

	String zone_location;
	int idzone_location;
	
	public String getZone_location() {
		return zone_location;
	}
	public void setZone_location(String zone_location) {
		this.zone_location = zone_location;
	}
	public int getIdzone_location() {
		return idzone_location;
	}
	public void setIdzone_location(int idzone_location) {
		this.idzone_location = idzone_location;
	}
	

	
	
}

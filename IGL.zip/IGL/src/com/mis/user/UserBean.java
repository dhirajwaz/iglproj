package com.mis.user;

import java.sql.Date;

public class UserBean {
	
	
	
	
	
 private	int id_user;
 private String  first_name ;
 private String  last_name ;
 private String  user_emailid ;
 private String password;
 private int  attempt_counter ;
 private String status ;
 private String  type_user ;
 private int  imei_number ;
 private int  user_role_id ;
 private String  created_by ;
 private Date  created_at;
 private String  updated_by;
 private Date  updated_at;
public int getId_user() {
	return id_user;
}
public void setId_user(int id_user) {
	this.id_user = id_user;
}
public String getFirst_name() {
	return first_name;
}
public void setFirst_name(String first_name) {
	this.first_name = first_name;
}
public String getLast_name() {
	return last_name;
}
public void setLast_name(String last_name) {
	this.last_name = last_name;
}
public String getUser_emailid() {
	return user_emailid;
}
public void setUser_emailid(String user_emailid) {
	this.user_emailid = user_emailid;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getAttempt_counter() {
	return attempt_counter;
}
public void setAttempt_counter(int attempt_counter) {
	this.attempt_counter = attempt_counter;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getType_user() {
	return type_user;
}
public void setType_user(String type_user) {
	this.type_user = type_user;
}
public int getImei_number() {
	return imei_number;
}
public void setImei_number(int imei_number) {
	this.imei_number = imei_number;
}
public int getUser_role_id() {
	return user_role_id;
}
public void setUser_role_id(int user_role_id) {
	this.user_role_id = user_role_id;
}
public String getCreated_by() {
	return created_by;
}
public void setCreated_by(String created_by) {
	this.created_by = created_by;
}
public Date getCreated_at() {
	return created_at;
}
public void setCreated_at(Date created_at) {
	this.created_at = created_at;
}
public String getUpdated_by() {
	return updated_by;
}
public void setUpdated_by(String updated_by) {
	this.updated_by = updated_by;
}
public Date getUpdated_at() {
	return updated_at;
}
public void setUpdated_at(Date updated_at) {
	this.updated_at = updated_at;
}	
 
 
	

}
package com.mis.user;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;


import Decoder.BASE64Decoder;

public class dycryptpass
{
  private static final String key = "aesEncryptionKey";
  
  public dycryptpass() {}
  
  public static String dycryptpass(String decryptedText)
  {
    try
    {
      byte[] keyData = "aesEncryptionKey".getBytes();
      SecretKeySpec secretKeySpec = new SecretKeySpec(keyData, "Blowfish");
      Cipher cipher = Cipher.getInstance("Blowfish");
      cipher.init(2, secretKeySpec);
   byte[] hasil = cipher.doFinal(new BASE64Decoder().decodeBuffer(decryptedText));
      return new String(hasil);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    
    return null;
  }
}
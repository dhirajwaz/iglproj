package com.mis.user;

import java.io.IOException;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Decoder.BASE64Encoder;



@WebServlet({"/ProtectorPass"})
public class ProtectorPass
  extends HttpServlet
{
  private static final long serialVersionUID = 1L;
  private static final String key = "aesEncryptionKey";
  
  public ProtectorPass() {}
  
  
   protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
      final HttpSession session = request.getSession();
      final String password = request.getParameter("t2");
      final String emplno = request.getParameter("user_emailid");
      final String encryptedText = encrypt(password);;
      System.out.println("Encrypted Text After Encryption: " + encryptedText);
      session.setAttribute("empl", (Object)emplno);
      session.setAttribute("encrypt", (Object)encryptedText);
      final String sessionid = request.getSession().getId();
      final String contextPath = request.getContextPath();
      response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      response.setHeader("Pragma", "no-cache");
      response.setDateHeader("Expires", 0L);
      response.setHeader("ACCEPT", "application/xaml+xml");
      response.sendRedirect("login-process.jsp");
  }

  
  
  
  
  
  
  
  /*protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    HttpSession session = request.getSession();
    
    String password = request.getParameter("t2");
    String emplno = request.getParameter("email");
    System.out.println("Password : " + password);

    //String encryptedText = encrypt(password);
   // System.out.println("Encrypted Text After Encryption: " + encryptedText);
    
    session.setAttribute("empl", emplno);
   // session.setAttribute("encrypt", encryptedText);
    
    String sessionid = request.getSession().getId();
    String contextPath = request.getContextPath();
    
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
    response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
    response.setDateHeader("Expires", 0); // Proxies
    response.setHeader("ACCEPT", "application/xaml+xml");
    
    response.sendRedirect("login-process.jsp");
  }*/
  

	
	  public static String encrypt(String strToEncrypt) { 
		  try { 
			  byte[] keyData ="aesEncryptionKey".getBytes(); 
			  SecretKeySpec secretKeySpec = new SecretKeySpec(keyData, "Blowfish"); 
			  Cipher cipher = Cipher.getInstance("Blowfish"); 
			  cipher.init(1, secretKeySpec); byte[] hasil = cipher.doFinal(strToEncrypt.getBytes()); 
			  return new BASE64Encoder().encode(hasil); 
			  } 
		  catch (Exception ex) { 
			  ex.printStackTrace();
	  } 
		  return null; 
		  }
	 
}

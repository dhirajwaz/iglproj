package com.mis.action;

import java.sql.PreparedStatement;
import java.sql.Connection;
import com.mis.dbaction.DatabaseConnection;
import java.io.IOException;
import javax.servlet.ServletException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/ActionDelete" })
public class ActionDelete extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        final PrintWriter out = response.getWriter();
        response.setContentType("txt/html");
        final String id = request.getParameter("hid");
        final String mname = request.getParameter("mname");
        out.println(id);
        String query = "";
        if (mname.equals("m1")) {
            query = "delete from fmod where id_fmod=?";
        }
        else if (mname.equals("m2")) {
            query = "delete from fire_engine where idfire_engine=?";
        }
        else if (mname.equals("m3")) {
            query = "delete from fire_water_storage_tbl where fid_storage=?";
        }
        else if (mname.equals("m4")) {
            query = "delete from mdt_storage_vessels where idmdt_sv=?";
        }
        else if (mname.equals("m5")) {
            query = "delete from safety_equipment_table where se_id=?";
        }
        else if (mname.equals("m6")) {
            query = "delete from incident_table where in_id=?";
        }
        else if (mname.equals("m7")) {
            query = "delete from fire_drill_table where fd_id=?";
        }
        else if (mname.equals("m8")) {
            query = "delete from training_event_table where te_id=?";
        }
        else if (mname.equals("m10")) {
            query = "delete from audit_compliance_table where ac_id=?";
        }
        final int flag = this.actionDeleted(id, query);
        out.print(flag);
    }
    
    private int actionDeleted(final String hId, final String query) {
        Connection conn = null;
        PreparedStatement ps = null;
        int success = 0;
        try {
            conn = DatabaseConnection.getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, hId);
            success = ps.executeUpdate();
            ps.close();
            conn.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return success;
    }
}
package com.mis.action;

import java.sql.SQLException;
import com.mysql.jdbc.PreparedStatement;
import com.mis.dbaction.DatabaseConnection;
import com.mysql.jdbc.Connection;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/insertUser" })
public class insertUser extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        
        final String employeename = request.getParameter("name");
        final String employeeemail = request.getParameter("user_emailid");
        //String employeezone = request.getParameter("userzone");
        String userstatus = request.getParameter("userstatus");
        final String employeetype = request.getParameter("typeuser");
      //  final String newornot = request.getParameter("isnew");
        try {
            final Connection con = (Connection)DatabaseConnection.getConnection();
            int status = 0;
          //  if (newornot.equals("0")) {
              /*  final String query = "update super_admin set user_name=?, user_emailid=?, user_zone=?, plant_code=?, type_user=? where emplno=?";
               
                final PreparedStatement ps = (PreparedStatement)con.prepareStatement(query);
                ps.setString(1, employeename);
                ps.setString(2, employeeemail);
                ps.setString(3, employeezone);
                ps.setString(4, employeeplant);
                ps.setString(5, employeetype);
              
                status = ps.executeUpdate();
                ps.close();
            }
            else {*/
            
                final String query = "insert into igl_web_mobile_users(first_name,user_emailid,password,status,type_user) values(?,?,?,?,?)";
                
                final PreparedStatement ps = (PreparedStatement)con.prepareStatement(query);
                ps.setString(1, employeename);
                ps.setString(2, employeeemail);
                ps.setString(3, "12345");
                ps.setString(4, userstatus);
               // ps.setString(5, employeezone);               
                ps.setString(6, employeetype);
                status = ps.executeUpdate();
                ps.close();
           
                
            con.close();
            if (status == 1) {
                response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                response.setHeader("Pragma", "no-cache");
                response.setDateHeader("Expires", 0L);
                response.sendRedirect("user-process.jsp");
            }
            else {
                response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
                response.setHeader("Pragma", "no-cache");
                response.setDateHeader("Expires", 0L);
                response.sendRedirect("user-process.jsp");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
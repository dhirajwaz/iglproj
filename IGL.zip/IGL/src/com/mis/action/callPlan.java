package com.mis.action;

import java.io.IOException;
import javax.servlet.ServletException;
import java.sql.ResultSet;
import java.util.Arrays;
import java.sql.SQLException;
import com.mysql.jdbc.PreparedStatement;
import com.mis.dbaction.DatabaseConnection;
import com.mysql.jdbc.Connection;
import java.util.HashMap;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/callingPlant" })
public class callPlan extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    
    protected void doPost(final HttpServletRequest request, final HttpServletResponse response) throws ServletException, IOException {
        final HashMap<Integer, String> plantValues = new HashMap<Integer, String>();
        Object[] objarr = null;
        final String employeezoneid = request.getParameter("zoneidval");
        try {
            final Connection con = (Connection)DatabaseConnection.getConnection();
            final String query = "SELECT plant_code,plant_name FROM plant_location where zone_id=?";
            final PreparedStatement ps = (PreparedStatement)con.prepareStatement(query);
            ps.setString(1, employeezoneid);
            final ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                plantValues.put(rs.getInt("plant_code"), rs.getString("plant_name"));
            }
            objarr = plantValues.entrySet().toArray();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        response.getWriter().write(Arrays.toString(objarr));
    }
}
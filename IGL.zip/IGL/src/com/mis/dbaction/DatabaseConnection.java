package com.mis.dbaction;

import java.sql.Connection;

public class DatabaseConnection {
  public DatabaseConnection() {}
  
  public static Connection getConnection() { Connection con = null;
    try {
      Class.forName("com.mysql.jdbc.Driver");
      
      con = java.sql.DriverManager.getConnection("jdbc:mysql://49.50.118.112:3309/igl_db","root","(AdfZo$ODO$D");  
      
    } catch (Exception e) { System.out.println(e); }
    return con;
  }
}
